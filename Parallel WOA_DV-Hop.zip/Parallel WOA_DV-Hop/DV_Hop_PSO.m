function [ gbest,fitnessgbest,T ] = DV_Hop_PSO(  D, ps, Max_nfe, Xmin, Xmax, Distance,m,BeaconAmount,Beacon,hop1 )

rand('state',sum(100*clock));



c = 2.0;
w = 0.9;
sizepop = ps;
maxgen = Max_nfe;
Vmax = Xmax/10;
Vmin = -Vmax;
popmax = Xmax;
popmin = Xmin;
for i = 1:sizepop
    % �������һ����Ⱥ
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %��ʼ��Ⱥ
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %��ʼ���ٶ�
    % ������Ӧ��
    fitness(:,i)=fun_w(Distance,pop(i,:),m,BeaconAmount,Beacon,hop1);
end
% fitness = feval(fhd,pop',varargin{:});


%% V. ���弫ֵ��Ⱥ�弫ֵ

[bestfitness,bestindex] = min(fitness);
GP = bestindex;
pbest = pop;    %�������
gbest = pop(bestindex,:);   %ȫ�����
fitnesspbest = fitness;%���������Ӧ��ֵ

fitnessgbest = bestfitness;%ȫ�������Ӧ��ֵ





for G = 1:maxgen
    w = fix(10-5*G/maxgen)/10;
    
    for i = 1:sizepop
        V(i,:) = w*V(i,:)+c*rand*(pbest(i,:) -pop(i,:))+c*rand*(gbest-pop(i,:));
        
        V(i,:) = max(Vmin,min(Vmax,V(i,:))); 
        pop(i,:) = pop(i,:)+V(i,:);
        pop(i,:) = max(popmin,min(popmax,pop(i,:)));
        
%         fitness(i) = feval(fhd,pop(i,:)',varargin{:});
        fitness(:,i)=fun_w(Distance,pop(i,:),m,BeaconAmount,Beacon,hop1);
        
        if fitness(i)<fitnesspbest(i)
            fitnesspbest(i) = fitness(i);
            pbest(i,:) = pop(i,:);
            if fitness(i)<fitnessgbest
                fitnessgbest = fitness(i);
                gbest = pop(i,:);
            end
        end
        
    end
    
    T(G) = fitnessgbest;
end





end

