% clear all
% mex cec13_func.cpp -DWINDOWS
clear
func_num=1;
dim = 40;
ub = 100;
lb = -100;
SearchAgents_no = 40;
iter_max = 1000;
fhd=str2func('cec13_func');
fun_name = {'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10','F11', 'F12', 'F13', 'F14', 'F15',...
    'F16', 'F17', 'F18', 'F19', 'F20','F21','F22','F23'};
for i = 1:23
    func_num = i;
    for j = 1:5
        i,j,
        fun_name{i}
        Function_name= fun_name{i}; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)
%         Function_name = 'F17';
        [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
        
%         [TotalBest,T] = AusWOA(iter_max,SearchAgents_no,lb,ub,dim,fobj);
%         [TotalBest,T] = AusPWOA(iter_max,SearchAgents_no,lb,ub,dim,fobj);
%         [TotalBest,T] = AusPWOAS1(iter_max,SearchAgents_no,lb,ub,dim,fobj);
%         [TotalBest,T] = AusPWOAS2(iter_max,SearchAgents_no,lb,ub,dim,fobj);
%         [TotalBest,T] = AusPWOAS3(iter_max,SearchAgents_no,lb,ub,dim,fobj);
%         [TotalBest,T] = PSO(iter_max,SearchAgents_no,lb,ub,dim,fobj);
[TotalBest,T] = BH(iter_max,SearchAgents_no,lb,ub,dim,fobj);
        
        
        fbest(i,j)=TotalBest;
        I = iter_max;
        for t = (I/20):(I/20):I
            a = t/(I/20);
            FV(j,a) =  T(t);
        end
    end
    for g = 1:20
        fv_mean(i,g) = mean(FV(:,g));
    end
    f_mean(i)=mean(fbest(i,:));
end

