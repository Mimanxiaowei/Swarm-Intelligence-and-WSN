function [fit]=fun_w(Distance,pop_node,i,BeaconAmount,Beacon,hop1)
    fit =0;
    for j=1:BeaconAmount
        %w = (1/hop1(j,i)); 
        w = (1/hop1(j,i))^2; 
        
        fit =fit+ w* (((((pop_node(1,1)-Beacon(1,j))^2+(pop_node(1,2)-Beacon(2,j))^2)^0.5) - Distance(j,i) ))^2;%���нڵ���໥����
       % fit =fit+abs(((((pop_node(1,1)-Beacon(1,j))^2+(pop_node(1,2)-Beacon(2,j))^2)^0.5) - Distance(j,i) ));%���нڵ���໥����
       
    end
    %fit=fit/BeaconAmount;