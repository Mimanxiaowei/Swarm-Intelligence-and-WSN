%_________________________________________________________________________%
%  Whale Optimization Algorithm (WOA) source codes demo 1.0               %
%                                                                         %
%  Developed in MATLAB R2011b(7.13)                                       %
%                                                                         %
%  Author and programmer: Seyedali Mirjalili                              %
%                                                                         %
%         e-Mail: ali.mirjalili@gmail.com                                 %
%                 seyedali.mirjalili@griffithuni.edu.au                   %
%                                                                         %
%       Homepage: http://www.alimirjalili.com                             %
%                                                                         %
%   Main paper: S. Mirjalili, A. Lewis                                    %
%               The Whale Optimization Algorithm,                         %
%               Advances in Engineering Software , in press,              %
%               DOI: http://dx.doi.org/10.1016/j.advengsoft.2016.01.008   %
%                                                                         %
%_________________________________________________________________________%


% The Whale Optimization Algorithm
function [Leader_score,Convergence_curve] = EcWOA(Max_iter,SearchAgents_no,lb,ub,dim,fhd,fun_num)

% initialize position vector and score for the leader
Leader_pos=zeros(1,dim);
Leader_score=inf; %change this to -inf for maximization problems

mu = zeros(1,dim);
sicma = 10*ones(1,dim);
Max_iter = SearchAgents_no*Max_iter;


%Initialize the positions of search agents
% Positions=initialization(SearchAgents_no,dim,ub,lb);
Positions=ub.*generateIndividualR(mu,sicma);
fitness=feval(fhd,Positions',fun_num);
% fitness =fobj(Positions);
if fitness<Leader_score % Change this to > for maximization problem
    Leader_score=fitness; % Update alpha
    Leader_pos=Positions;
end


Convergence_curve=zeros(1,Max_iter);
o = 0;

t=0;% Loop counter

% Main loop
while t<Max_iter

    Pop = 200+fix(2800*t/Max_iter);
    
    a=2-t*((2)/Max_iter); % a decreases linearly fron 2 to 0 in Eq. (2.3)
    
    % a2 linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
    a2=-1+t*((-1)/Max_iter);
    
    % Update the Position of search agents
    r1=rand(); % r1 is a random number in [0,1]
    r2=rand(); % r2 is a random number in [0,1]
    
    A=2*a*r1-a;  % Eq. (2.3) in the paper
    C=2*r2;      % Eq. (2.4) in the paper
    
    
    b=1;               %  parameters in Eq. (2.5)
    l=(a2-1)*rand+1;   %  parameters in Eq. (2.5)
    
    p = rand();        % p in Eq. (2.6)
    LastPositions = Positions;
    Lastfitness = fitness;
    for j = 1:size(Positions,2)
        if p<0.5
            if abs(A)>=1
%              X_rand = ub.*generateIndividualR(mu,sicma);
                 X_rand = rand(1,dim)*2*ub+lb;
                %                 X_rand = 0.6*X+0.4*(Positions-X);
%                 X_rand = X+(Leader_pos+Positions)/2;
                D_X_rand=abs(C*X_rand(j)-Positions(j)); % Eq. (2.7)
                Positions(j)=X_rand(j)-A*D_X_rand; 
                
            elseif abs(A)<1
                D_Leader=abs(C*Leader_pos(j)-Positions(j)); % Eq. (2.1)
                Positions(j)=Leader_pos(j)-A*D_Leader;      % Eq. (2.2)
            end
            
        elseif p>=0.5
            
            distance2Leader=abs(Leader_pos(j)-Positions(j));
            % Eq. (2.5)
            Positions(j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+Leader_pos(j);
            
        end
        
        
    end
    Positions = min(ub,max(lb,Positions));
    
    % Calculate objective function for each search agent
        fitness=feval(fhd,Positions',fun_num);
%     fitness =fobj(Positions);
    
    % Update the leader
    if fitness<Leader_score % Change this to > for maximization problem
        Leader_score=fitness; % Update alpha
        Leader_pos=Positions;
    end
    if fitness < Lastfitness
        mu = updateMuPV(Positions,LastPositions,mu,Pop,dim);
        sicma = updateSicmaPV(Positions,LastPositions,mu,sicma,Pop,dim);
    end
    Positions=ub.*generateIndividualR(mu,sicma);
    
    t=t+1;
    Convergence_curve(t) = Leader_score;
    %     [t Leader_score]
end



