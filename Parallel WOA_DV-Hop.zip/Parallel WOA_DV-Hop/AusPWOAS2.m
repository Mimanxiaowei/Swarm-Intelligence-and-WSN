
function [TotalBest,Convergence_curve] = AusPWOAS2(Max_iter,SearchAgents_no,lb,ub,dim,fobj)

TotalPositon = zeros(1,dim);
TotalBest = inf;

groups = 4;
SearchAgents_no = SearchAgents_no/groups;
Convergence_curve=zeros(1,Max_iter);
Limit = 10;
for g = 1:groups
    group(g).Leader_pos=zeros(1,dim);
    group(g).Leader_score=inf;
    group(g).Positions=initialization(SearchAgents_no,dim,ub,lb); 
    group(g).limit = 0;
end
t=1;

while t<Max_iter+1
    for g = 1:groups
        for i=1:SearchAgents_no
            group(g).Positions(i,:) = min(ub,max(lb,(group(g).Positions(i,:))));
            group(g).fitness(i) =fobj(group(g).Positions(i,:));
        end
        [group(g).fitnessbest,group(g).bestindex] = min(group(g).fitness);
        
        if group(g).fitnessbest<group(g).Leader_score % Change this to > for maximization problem
            group(g).Leader_score = group(g).fitnessbest; % Update alpha
            group(g).Leader_pos=group(g).Positions(group(g).bestindex,:);
            if group(g).fitnessbest < TotalBest
                TotalPositon = group(g).Positions(group(g).bestindex,:);
                TotalBest = group(g).fitnessbest;
            end
        else
            group(g).limit = group(g).limit+1;
        end
        if group(g).limit > Limit
            group(g).Leader_score = TotalBest;
            group(g).Leader_pos = TotalPositon;
            group(g).limit = 0;
        end
        
        a=2-t*((2)/Max_iter); % a decreases linearly fron 2 to 0 in Eq. (2.3)
        
        % a2 linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
        a2=-1+t*((-1)/Max_iter);
        for i=1:SearchAgents_no
            r1=rand(); % r1 is a random number in [0,1]
            r2=rand(); % r2 is a random number in [0,1]
            
            A=2*a*r1-a;  % Eq. (2.3) in the paper
            C=2*r2;      % Eq. (2.4) in the paper
            
            
            b=1;               %  parameters in Eq. (2.5)
            l=(a2-1)*rand+1;   %  parameters in Eq. (2.5)
            
            p = rand();        % p in Eq. (2.6)
            
            for j=1:dim
                
                if p<0.5
                    if abs(A)>=1
                        rand_leader_index = floor(SearchAgents_no*rand()+1);
                        X_rand = group(g).Positions(rand_leader_index, :);
                        D_X_rand=abs(C*X_rand(j)-group(g).Positions(i,j)); % Eq. (2.7)
                        group(g).Positions(i,j)=X_rand(j)-A*D_X_rand;      % Eq. (2.8)
                        
                    elseif abs(A)<1
                        D_Leader=abs(C*group(g).Leader_pos(j)-group(g).Positions(i,j)); % Eq. (2.1)
                        group(g).Positions(i,j)=group(g).Leader_pos(j)-A*D_Leader;      % Eq. (2.2)
                    end
                    
                elseif p>=0.5
                    
                    distance2Leader=abs(group(g).Leader_pos(j)-group(g).Positions(i,j));
                    % Eq. (2.5)
                    group(g).Positions(i,j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+group(g).Leader_pos(j);
                    
                end
                
            end
        end
          
        %     [t Leader_score]
    end
    t=t+1; 
    Convergence_curve(t) = TotalBest;
end


end

