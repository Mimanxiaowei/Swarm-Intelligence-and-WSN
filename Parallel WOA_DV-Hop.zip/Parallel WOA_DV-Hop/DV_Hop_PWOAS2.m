function [TotalBestPosition,TotalBest,Convergence_curve] = DV_Hop_PWOAS2(D, ps, Max_nfe, Xmin, Xmax, Distance,m,BeaconAmount,Beacon,hop1)


Max_iter = Max_nfe;
dim = D;
lb = Xmin;
ub = Xmax;
SearchAgents_no = ps;


TotalBestPosition = zeros(1,dim);
TotalBest = inf;

groups = 4;
SearchAgents_no = SearchAgents_no/groups;
Convergence_curve=zeros(1,Max_iter);
for g = 1:groups
    group(g).Leader_pos=zeros(1,dim);
    group(g).Leader_score=inf;
    group(g).Positions=initialization(SearchAgents_no,dim,ub,lb);
end
t=1;

while t<Max_iter+1
    if rem(t,12) == 0
         Pop_sum = zeros(1,dim);
         for g = 1:groups
             for i = 1:SearchAgents_no
                 Pop_sum = group(g).Positions(i,:) + Pop_sum;
             end
             
         end
         Pop_mean = Pop_sum/SearchAgents_no;
    end
    
    
    for g = 1:groups
        
         if rem(t,20) == 0
            R = randperm(SearchAgents_no,1);
            change_no = fix(dim/4);
            para2change = randperm(dim,change_no);
            Rhead = R;
            Rend = R+10;
            Rend = min(SearchAgents_no,Rend);
            for r = Rhead:Rend
                for d = 1:change_no
                    group(g).Positions(r,para2change(d)) = (0.8+rand*0.4)*Pop_mean(para2change(d));
                end
               
            end
         end
        
         
        for i=1:SearchAgents_no
            group(g).Positions(i,:) = min(ub,max(lb,(group(g).Positions(i,:))));
%             group(g).fitness(i) =fobj(group(g).Positions(i,:));
            group(g).fitness(:,i)=fun_w(Distance,group(g).Positions(i,:),m,BeaconAmount,Beacon,hop1);
        end
        [group(g).fitnessbest,group(g).bestindex] = min(group(g).fitness);
        
        if group(g).fitnessbest<group(g).Leader_score % Change this to > for maximization problem
            group(g).Leader_score = group(g).fitnessbest; % Update alpha
            group(g).Leader_pos=group(g).Positions(group(g).bestindex,:);
            if group(g).fitnessbest < TotalBest
                TotalBestPosition = group(g).Positions(group(g).bestindex,:);
                TotalBest = group(g).fitnessbest;
            end
        end
        
        a=2-t*((2)/Max_iter); % a decreases linearly fron 2 to 0 in Eq. (2.3)
        
        % a2 linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
        a2=-1+t*((-1)/Max_iter);
        for i=1:SearchAgents_no
            r1=rand(); % r1 is a random number in [0,1]
            r2=rand(); % r2 is a random number in [0,1]
            
            A=2*a*r1-a;  % Eq. (2.3) in the paper
            C=2*r2;      % Eq. (2.4) in the paper
            
            
            b=1;               %  parameters in Eq. (2.5)
            l=(a2-1)*rand+1;   %  parameters in Eq. (2.5)
            
            p = rand();        % p in Eq. (2.6)
            
            for j=1:dim
                
                if p<0.5
                    if abs(A)>=1
                        rand_leader_index = floor(SearchAgents_no*rand()+1);
                        X_rand = group(g).Positions(rand_leader_index, :);
                        D_X_rand=abs(C*X_rand(j)-group(g).Positions(i,j)); % Eq. (2.7)
                        group(g).Positions(i,j)=X_rand(j)-A*D_X_rand;      % Eq. (2.8)
                        
                    elseif abs(A)<1
                        D_Leader=abs(C*group(g).Leader_pos(j)-group(g).Positions(i,j)); % Eq. (2.1)
                        group(g).Positions(i,j)=group(g).Leader_pos(j)-A*D_Leader;      % Eq. (2.2)
                    end
                    
                elseif p>=0.5
                    
                    distance2Leader=abs(group(g).Leader_pos(j)-group(g).Positions(i,j));
                    % Eq. (2.5)
                    group(g).Positions(i,j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+group(g).Leader_pos(j);
                    
                end
                
            end
        end
        
        %     [t Leader_score]
    end
    t=t+1;
    Convergence_curve(t) = TotalBest;
end


end





