function [Foods,fitness,limit] = EmployedBee( fhd,fun_num,FoodNumber,Dim,Down,Up,Foods,fitness,limit,Limit )
%EMPLOYEDBEE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

EmployedBee = Foods;
efitness = feval(fhd,EmployedBee',fun_num);

for i = 1:FoodNumber
%     if efitness(i) < fitness(i)
%         fitness(i) = efitness(i);
%     end
    DimMu = randperm(Dim,1);
    k = randperm(FoodNumber,1);
    while(i==k)
       k = randperm(FoodNumber,1); 
    end
        EmployedBee(i,DimMu) = Foods(i,DimMu)+(-1+2*rand)*EmployedBee(k,DimMu);
        EmployedBee(i,DimMu) = min(Up(1,1),max(Down(1,1),EmployedBee(i,DimMu)));
    efitness(i) = feval(fhd,EmployedBee(i,:)',fun_num);
    if efitness(i) < fitness(i)
        Foods(i,:) = EmployedBee(i,:);
        fitness(i) = efitness(i);
    else
        limit(i) = limit(i)+1;
    end
    if limit(i) >= Limit
        limit(i) = 0;
        Foods(i,:) = rand().*(Up(1,:)*2)+Down(1,:);
        fitness(i) = feval(fhd,Foods(i,:)',fun_num);
    end
    
end

end

