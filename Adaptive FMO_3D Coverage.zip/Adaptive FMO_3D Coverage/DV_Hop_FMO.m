function gbest = DV_Hop_FMO( D, ps, Max_nfe, Xmin, Xmax, Distance,m,BeaconAmount,Beacon,hop1,coordinate,anchor_high )


sizepop = ps;
maxgen = Max_nfe;
Vmax = Xmax/20;
Vmin = -Vmax;
popmax = Xmax;
popmin = Xmin;
stage = zeros(sizepop,1);
E_max = 200;
c = pi/10;
enger = E_max*ones(sizepop,1);
% pop = 1+popmin+(popmax-popmin-1)*rand(sizepop,D);    %��ʼ��Ⱥ
% V = Vmin+(Vmax-Vmin)*rand(sizepop,D);
% fitness = feval(fhd,pop',varargin{:});
for i = 1:sizepop
    % �������һ����Ⱥ
    pop(i,:) = 1+popmin+(popmax-popmin-1).*rand(1,D);    %��ʼ��Ⱥ
    high(i) = coordinate(round(pop(i,1)),round(pop(i,2)));
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %��ʼ���ٶ�
    % ������Ӧ��
    fitness(i)=fun_w(Distance,pop(i,:),m,BeaconAmount,Beacon,hop1,high(i),anchor_high);
end
% prepop = pop;
[temfitness,temindex] = min(fitness);
fitnessgbest = temfitness;
i = 0;
for i = 1:maxgen
    w = 2-1.6*i/maxgen;
    for j = 1:sizepop
        r = randperm(sizepop,1);
        V(j,:) = w*(pop(temindex,:)-pop(j,:))*enger(j)/E_max+(fitness(j)-fitness(r))\abs(fitness(j)-fitness(r))...
            *c*rand*(pop(r,:)-pop(j,:));
        V(j,:) = max(Vmin,min(Vmax,V(j,:)));
        pop(j,:) = pop(j,:)+V(j,:);
        pop(j,:) = max(popmin+1,min(popmax,pop(j,:)));
        high(j) = coordinate(round(pop(j,1)),round(pop(j,2)));
        fitness(j)=fun_w(Distance,pop(j,:),m,BeaconAmount,Beacon,hop1,high(j),anchor_high);
%         fitness(j) = feval(fhd,pop(j,:)',varargin{:});
        if fitness(j)>fitnessgbest
            enger(j) = enger(j)+(0.2+0.4*rand)*E_max*abs((fitness(j)-fitnessgbest)/(max(fitness)-fitnessgbest));
            if enger(j) > (2+10*rand*i/maxgen)*E_max
                stage(j) = stage(j)+1;
            end
        end
    end
stage_2 = find(stage == 2);
stage_3 = find(stage == 3);
stage_4 = find(stage == 4);
for s2 = 1:size(stage_2,1)
    if rand <0.15
        pop(stage_2(s2),:) = 1+popmin+(popmax-popmin-1)*rand(1,D);
%         fitness(stage_2(s2)) = feval(fhd,pop(stage_2(s2),:)',varargin{:});
        high(stage_2(s2)) = coordinate(round(pop(stage_2(s2),1)),round(pop(stage_2(s2),2)));
        fitness(stage_2(s2))=fun_w(Distance,pop(stage_2(s2),:),m,BeaconAmount,Beacon,hop1,high(stage_2(s2)),anchor_high);
        stage(stage_2(s2)) = 0;
        enger(stage_2(s2)) = E_max;
    end
end
for s3 = 1:size(stage_3,1)
    if rand < 0.35
        pop(stage_3(s3),:) = 1+popmin+(popmax-popmin-1)*rand(1,D);
%         fitness(stage_3(s3)) = feval(fhd,pop(stage_3(s3),:)',varargin{:});
        high(stage_3(s3)) = coordinate(round(pop(stage_3(s3),1)),round(pop(stage_3(s3),2)));
        fitness(stage_3(s3))=fun_w(Distance,pop(stage_3(s3),:),m,BeaconAmount,Beacon,hop1,high(stage_3(s3)),anchor_high);
        stage(stage_3(s3)) = 0;
        enger(stage_3(s3)) = E_max;
    end
end
for s4 = 1:size(stage_4,1)
    pop(stage_4(s4),:) = 1+popmin+(popmax-popmin-1)*rand(1,D);
%     fitness(stage_4(s4)) = feval(fhd,pop(stage_4(s4),:)',varargin{:});
    high(stage_4(s4)) = coordinate(round(pop(stage_4(s4),1)),round(pop(stage_4(s4),2)));
    fitness(stage_4(s4))=fun_w(Distance,pop(stage_4(s4),:),m,BeaconAmount,Beacon,hop1,high(stage_4(s4)),anchor_high);
    stage(stage_4(s4)) = 0;
    enger(stage_4(s4)) = E_max;
end
% [fitnessgbest,bestindex] = min(fitness);
[temfitness,temindex] = min(fitness);
gbest = pop(temindex,:);
if temfitness < fitnessgbest
    fitnessgbest = temfitness;
    bestindex = temindex;
    gbest = pop(bestindex,:);
end
T(i) = fitnessgbest;
end

end

