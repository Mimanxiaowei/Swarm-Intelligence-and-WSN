[x,y,coordinate] = peaks(100);
surf(x,y,coordinate);
% save coordinate.mat coordinate;
clc
clear
load coordinate.mat;
% surf(coordinate);
boundary = 100;
Radius = 20;
Node_num = 500;
Anchor_num = 30;
Unknown_num = Node_num - Anchor_num;
% Positions = 1+(boundary-1)*rand(Node_num,2);
% save 450nodes.mat Positions;
load 500nodes
for i = 1:Node_num
    Position_high(i) = coordinate(round(Positions(i,1)),round(Positions(i,2)));
end
for i = 1:Node_num
    for j = 1:Node_num
        Hops(i,j) = inf;
        Hops(j,i) = inf;
        if i == j
            Hops(i,j) = 0;
            break;
        end
        distance = Distance(Positions(i,:),Positions(j,:),3,Position_high(i),Position_high(j));
        Dist(i,j) = distance;
        Dist(j,i) = distance;
        if distance < Radius
            a = 1;
            C = Positions(j,1);
            V = Positions(j,2);
            [v,d] = max(abs(Positions(i,1:2) - Positions(j,1:2)));%Ѱ�ұ仯�Ƚϴ��ά�ȣ�d�����仯���ά�ȣ�a��ʾ�仯�Ƚ�С��ά��
            if d == 1
                a = 2;
                C = Positions(j,2);
                V = Positions(j,1);
            end
            k = (C - Positions(i,a)) / (V - Positions(i,d));%x,y֮���б��
            h = (Position_high(j) - Position_high(i)) / (V - Positions(i,d));%�߶Ⱥͱ仯�ϴ�ά��֮���б��
            %%
            Differ = abs(fix(Positions(i,d)) - V)-1;
            if (fix(Positions(i,d)) - V) < 0
                symbol = 1;
                start_d = fix(Positions(i,d))+1;
            else
                symbol = -1;
                start_d = fix(Positions(i,d));
            end
            start_a = Positions(i,a) + k*(start_d - Positions(i,d));
            start_h = Position_high(i) + h*(start_d - Positions(i,d));
            for s = 1:Differ
                D = start_d + s * symbol;
                A = start_a + s * symbol * k;
                A = min(boundary,A);
                High = start_h + s * symbol * h;
                if a == 1
                    if coordinate(round(A),round(D)) <  High || coordinate(round(A),round(D)) ==  High
                        Hops(i,j) = 1;
                        Hops(j,i) = 1;
                    end
                else
                    if coordinate(round(D),round(A)) <  High || coordinate(round(D),round(A)) ==  High
                        Hops(i,j) = 1;
                        Hops(j,i) = 1;
                    end
                end
            end
        end
    end
end
for k=1:Node_num
    for i=1:Node_num
        for j=1:Node_num
            if Hops(i,k)+Hops(k,j)<Hops(i,j)%min(h(i,j),h(i,k)+h(k,j))
                Hops(i,j)=Hops(i,k)+Hops(k,j);
            end
        end
    end
end
% for i = 1:Node_num
%     for j = i+1:Node_num
%         if Hops(i,j) == inf
%             Hops(i,j) = 0;
%             Hops(j,i) = 0;
%         end
%     end
% end

Hops_anchor = Hops(1:Anchor_num,1:Anchor_num);
Distance_anchor = Dist(1:Anchor_num,1:Anchor_num);
for i=1:Anchor_num
    fz =  sum(Distance_anchor(i,:).*Hops_anchor(i,:));
    fm = sum(Hops_anchor(i,:).^2);
    Hops_size(i)=fz/fm;%ÿ���ű�ڵ��ƽ��ÿ������
end

Distance_AU = Dist(1:Anchor_num,(Anchor_num+1):Node_num);

for j = 1:Unknown_num
    hop_size(j)=0;
    for i = 1:Anchor_num
        % Dhop(1,j)=Dhop(1,j)+(h(i,j)*dhop(i,1)/sum(h(i,1:BeaconAmount)));%δ֪�ڵ��������ű���У��ֵ
        hop_size(j) = hop_size(j)+(Hops(i,Anchor_num+j)*Hops_size(i)/sum(Hops(1:Anchor_num,Anchor_num+j)));%δ֪�ڵ��������ű���У��ֵ
    end
end

%~~~~~~~~~~~~~~~~���������ƾ���~~~~~~~~~~~~~~~~~~~
Hops_unknown = Hops(1:Anchor_num,(Anchor_num+1):Node_num);%δ֪�ڵ㵽�ű�������BeaconAmount��UNAmount��
for i=1:Unknown_num
    Hop = hop_size(i);
    Dis_AU(:,i)=Hop*Hops_unknown(:,i);%%Beacon��UN�У�
end

%% ȷ���ڵ�λ��
runs = 1;
d = Dis_AU;
Anchor = Positions(1:Anchor_num,:);
anchor_high = Position_high(1:Anchor_num);
Max_nfe = 100;
Xmin = 0;
Xmax = 100;
ps = 40;
D = 2;
for i = 1:Anchor_num
    A(i,1) = -2*Positions(i,1);
    A(i,2) = -2*Positions(i,2);
    A(i,3) = -2*Position_high(i);
    A(i,4) = 1;
end
for n = 1:runs
    n
    %% ��С���˷�
    for m = 1:Unknown_num
        for i = 1:Anchor_num
            B(i,1)=d(i,m)^2-Positions(i,1)^2-Positions(i,2)^2-Position_high(i)^2;
        end
        X1=inv(A'*A)*A'*B;
        X2(1,m) = X1(1,1);
        X2(2,m) = X1(2,1);
        X2(3,m) = X1(3,1);
    end
    
    
    %���ܼ���
%     for m = 1:Unknown_num
% %         gbest = DV_Hop_PSO(D, ps, Max_nfe, Xmin, Xmax, d,m,Anchor_num,Anchor,Hops_unknown,coordinate,anchor_high);
% %         gbest = DV_Hop_WOA(D, ps, Max_nfe, Xmin, Xmax, d,m,Anchor_num,Anchor,Hops_unknown,coordinate,anchor_high);
% %         gbest = DV_Hop_BH(D, ps, Max_nfe, Xmin, Xmax, d,m,Anchor_num,Anchor,Hops_unknown,coordinate,anchor_high);
%         gbest = DV_Hop_FMO(D, ps, Max_nfe, Xmin, Xmax, d,m,Anchor_num,Anchor,Hops_unknown,coordinate,anchor_high);
%         X2(1,m) = gbest(1);
%         X2(2,m) = gbest(2);
%         X2(3,m) = coordinate(round(gbest(1)),round(gbest(2)));
%     end
    for i=1:Unknown_num
        error2(i)=(((X2(1,i)-Positions(Anchor_num+i,1))^2+(X2(2,i)-Positions(Anchor_num+i,2))^2....
            +(X2(3,i)-Position_high(Anchor_num+i))^2)^0.5);
    end
    errors(n) = mean(error2);
    Accuracy(n) = errors(n)/Radius;
end
Error = mean(errors);
Accuracy_mean = mean(Accuracy);