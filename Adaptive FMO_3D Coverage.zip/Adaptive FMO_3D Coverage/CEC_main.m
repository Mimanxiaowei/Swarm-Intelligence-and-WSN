% clear all
% mex cec13_func.cpp -DWINDOWS
clear
func_num=1;
D = 20;
Vmin=-10;
Vmax=10;
popmax = 100;
popmin = -100;
pop_size = 30;
iter_max = 1000;
fhd=str2func('cec13_func');
for i = 1:28
    func_num = i;
    for j = 1:5
        i,j,
      
        [TotalBest,T]= FMO(fhd,D,pop_size,iter_max,popmin,popmax,func_num);
%         [TotalBest,T]= PSO(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= WOA(fhd,D,pop_size,iter_max,popmin,popmax,func_num);
%         [TotalBest,T]= BH(fhd,D,pop_size,iter_max,popmin,popmax,func_num);

%         [TotalBest,T]= NPP(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= NPPS3(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
        fbest(i,j)=TotalBest;
        for t = (iter_max/20):(iter_max/20):iter_max
            a = t/(iter_max/20);
           FV(j,a) =  T(t);
        end
    end
    for g = 1:20
        fv_mean(i,g) = mean(FV(:,g));
    end
    f_mean(i)=mean(fbest(i,:));
end

