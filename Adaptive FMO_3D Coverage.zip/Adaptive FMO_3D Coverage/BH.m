function [bh, T] = BH( fhd,D,pop_size,iter_max,popmin,popmax,func_num )
%BH �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
for i = 1:pop_size
    pop(i,:) = popmin+(popmax-popmin)*rand(1,D);    %��ʼ��Ⱥ
end
fitness = feval(fhd,pop',func_num);
[bh,bh_index] = min(fitness);
bh_position = pop(bh_index,:);
 R = bh/sum(fitness);
for g=1:iter_max
    for i=1:pop_size
        pop(i,:) = pop(i,:) + rand*(bh_position - pop(i,:));
        
        for d = 1:D
            pop(i,d) = max(popmin,min(popmax,pop(i,d)));
        end
        distance(i) = Dist(bh_position,pop(i,:),D);
        if distance(i) < R && i ~= bh_index
            pop(i,:) = popmin+(popmax-popmin)*rand(1,D);
        end
        fitness(i) = feval(fhd,pop(i,:)',func_num);
        if fitness(i) < bh
            bh_index = i;
            bh_position = pop(bh_index,:);
            bh = fitness(i);
        end
    end
    T(g) = bh;
end
end

