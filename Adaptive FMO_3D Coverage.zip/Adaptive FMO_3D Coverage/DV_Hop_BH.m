function bh_position = DV_Hop_BH( D, ps, Max_nfe, Xmin, Xmax, Distance,m,BeaconAmount,Beacon,hop1,coordinate,anchor_high )
%BH �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
pop_size = ps;
iter_max = Max_nfe;
popmin = Xmin+1;
popmax = Xmax-1;
for i = 1:pop_size
    pop(i,:) = popmin+(popmax-popmin)*rand(1,D); 
    high(i) = coordinate(round(pop(i,1)),round(pop(i,2)));
    fitness(:,i)=fun_w(Distance,pop(i,:),m,BeaconAmount,Beacon,hop1,high(i),anchor_high);
end
[bh,bh_index] = min(fitness);
bh_position = pop(bh_index,:);
 R = bh/sum(fitness);
for g=1:iter_max
    for i=1:pop_size
        pop(i,:) = pop(i,:) + rand*(bh_position - pop(i,:));
        
        for d = 1:D
            pop(i,d) = max(popmin,min(popmax,pop(i,d)));
        end
        distance(i) = Dist(bh_position,pop(i,:),D);
        if distance(i) < R && i ~= bh_index
            pop(i,:) = popmin+(popmax-popmin)*rand(1,D);
            high(i) = coordinate(round(pop(i,1)),round(pop(i,2)));
        end
        fitness(:,i)=fun_w(Distance,pop(i,:),m,BeaconAmount,Beacon,hop1,high(i),anchor_high);
        if fitness(i) < bh
            bh_index = i;
            bh_position = pop(bh_index,:);
            bh = fitness(i);
        end
    end
    T(g) = bh;
end
end


