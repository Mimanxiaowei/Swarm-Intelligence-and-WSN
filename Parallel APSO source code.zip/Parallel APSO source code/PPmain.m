% clear all
% mex cec13_func.cpp -DWINDOWS
tic
clear
func_num=1;
D = 20;
Vmin=-10;
Vmax=10;
popmax = 100;
popmin = -100;
pop_size = 40;
iter_max = 2000;
fhd=str2func('cec13_func');
for i = 5
    func_num = i;
    parfor j = 1:30
%     for j = 1:30
        i,j,
%         TotalBest= NG(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);

%         [TotalBest,T]= PSO(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= PP(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= PPS2(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= PPS3(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);

%         [TotalBest,T]= CCPSO(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= CCPSOS2(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);

%         [TotalBest,T]= APSO(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= APSOS1(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= APSOS2(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
        [TotalBest,T]= APSOS3(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);

%         [TotalBest,T]= NPP(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
%         [TotalBest,T]= NPPS3(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,func_num);
        fbest(i,j)=TotalBest;
%         for t = (iter_max/20):(iter_max/20):iter_max
%             a = t/(iter_max/20);
%            FV(j,a) =  T(t);
%         end
    end
%     for g = 1:20
%         fv_mean(i,g) = mean(FV(:,g));
%     end
%     f_mean(i)=mean(fbest(i,:));
end
toc

