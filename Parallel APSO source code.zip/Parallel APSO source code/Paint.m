PSO = xlsread('PAPSO','30D_PSO','31:58');
PPSOS3 = xlsread('PAPSO','30D_PPS3','31:58');
APSO = xlsread('PAPSO','30D_APSO','31:58');
APSOS3 = xlsread('PAPSO','30D_APSOS3','31:58');

for i = 8
    figure (i)
    plot(PSO(i,(1:20)),'r-o','LineWidth',1.5,'Marker','o','MarkerFaceColor','red',...
        'XTickLabel',{'0','100','200','300','400','500','600','700','800','900','1000'},...
    'FontWeight','bold',...
    'FontSize',12,...
    'FontName','Times New Roman');
    hold on;
    plot(PPSOS3(i,(1:20)),'m-','LineWidth',1.5,'Marker','v','MarkerFaceColor','m');
    hold on;
    plot(APSO(i,(1:20)),'g-','LineWidth',1.5,'Marker','s','MarkerFaceColor','g');
    hold on;
    plot(APSOS3(i,(1:20)),'b-','LineWidth',1.5,'Marker','x','MarkerFaceColor','b');
    hold on;
    legend('PSO','PPSO','APSO','PAPSO');
    box('on')
end