function [TotalBest,T] = NPPS3( fhd,Dimension,Particle_Number,Max_Gen,VRmin,VRmax,Popmin,Popmax,varargin)
%NPP �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��s
rand('state',sum(100*clock));
groups = 4;
for g = 1:groups
    group(g).c1 = 2.0;
    group(g).c2 = 2.0;
    group(g).w1 = 0.9;
    group(g).Status = 'S1';
end
D = Dimension;
sizepop = Particle_Number/groups;
maxgen = Max_Gen;
Vmax = VRmax;
Vmin = VRmin;
popmax = Popmax;
popmin = Popmin;

%% IV. ������ʼ���Ӻ��ٶ�
for g = 1:groups
    for i = 1:sizepop
        % �������һ����Ⱥ
        group(g).pop(i,:) = popmin+(popmax-popmin)*rand(1,D);    %��ʼ��Ⱥ
        group(g).V(i,:) = Vmin+(Vmax-Vmin)*rand(1,D);  %��ʼ���ٶ�
    end
    
    group(g).fitness = feval(fhd,group(g).pop',varargin{:});
end


%% V. ���弫ֵ��Ⱥ�弫ֵ
for g = 1:groups
    [group(g).bestfitness,group(g).bestindex] = min(group(g).fitness);
    group(g).pbest = group(g).pop;    %�������
    group(g).gbest = group(g).pop(group(g).bestindex,:);   %ȫ�����
    
    group(g).GP = group(g).bestindex;
    
    group(g).fitnesspbest = group(g).fitness;%���������Ӧ��ֵ
    group(g).fitnessgbest = group(g).bestfitness;%ȫ�������Ӧ��ֵ
end;

TotalBest = group(1).fitnessgbest;
TotalBestPosition = group(1).gbest;


% ccBest = group(1).pbest;
for g = 1:groups
    if group(g).fitnessgbest<TotalBest
        TotalBest = group(g).fitnessgbest;
        TotalBestPosition = group(g).gbest;
    end
end


for G = 1:maxgen
    
    for g = 1:groups
        if rem(G,20) == 0
            RH = int8(rand*sizepop);
            RE = RH+int8(rand*(sizepop/4));
            RH = max(1,min(sizepop,RH));
            RE = max(1,min(sizepop,RE));
            
            for r = RH:RE
                for d = 1:D
                    group(g).pop(r,d) = TotalBestPosition(d)*(0.9+0.2*rand);
                end
                group(g).pbest(r,:) = TotalBestPosition;
                group(g).fitnesspbest(r) = TotalBest;
            end
            
            group(g).gbest = TotalBestPosition;
            group(g).fitnessgbest = TotalBest;
        end
    end
    
    for g = 1:groups
        for i = 1:sizepop
            
            
            %% ����APSO��������Ⱥ
            
            group(g).V(i,:) = group(g).w1*group(g).V(i,:) + group(g).c1*rand*(group(g).pbest(i,:) - group(g).pop(i,:))...
                + group(g).c2*rand*(group(g).gbest - group(g).pop(i,:));
            
            for d = 1:D
                group(g).V(i,d) = max(Vmin,min(Vmax,group(g).V(i,d)));
            end
            
            % ��Ⱥ����
            group(g).pop(i,:) = group(g).pop(i,:)+group(g).V(i,:);
            
            %ȷ������λ�ò������߽�
            for d = 1:D
                group(g).pop(i,d) = max(popmin,min(popmax,group(g).pop(i,d)));
            end
            
            group(g).fitness(i) = feval(fhd,group(g).pop(i,:)',varargin{:});
            
            if group(g).fitness(i)<group(g).fitnesspbest(i)
                group(g).fitnesspbest(i) = group(g).fitness(i);
                group(g).pbest(i,:) = group(g).pop(i,:);
            end
            
            if group(g).fitness(i)<group(g).fitnessgbest
                group(g).fitnessgbest = group(g).fitness(i);
                group(g).gbest = group(g).pop(i,:);
                group(g).GP = i;
            end
            Rd = randperm(D,1);%��1-D�����ѡȡһ����
            variance = 1.0-0.9*i/maxgen;
            %         Z = popmin+(popmax-popmin)*gaussmf(group(g).gbest(Rd),[variance 0]);
            group(g).Jump = group(g).gbest(Rd)-17+rand*34;
            %         group(g).Jump = group(g).gbest(Rd)+Z;
            group(g).Jump = max(popmin,min(popmax,group(g).Jump));
            group(g).Ju = group(g).gbest;
            group(g).Ju(Rd) = group(g).Jump;
            group(g).Jumpfitness = feval(fhd,group(g).Ju',varargin{:});
            if group(g).Jumpfitness < group(g).fitnessgbest
                group(g).pop( group(g).GP,:) = group(g).Ju;
                group(g).pbest( group(g).GP,:) = group(g).Ju;
                group(g).gbest = group(g).Ju;
                group(g).fitnesspbest( group(g).GP) = group(g).Jumpfitness;
                group(g).fitnessgbest = group(g).Jumpfitness;
            end
        end
        if group(g).fitnessgbest <TotalBest
            TotalBest = group(g).fitnessgbest;
            TotalBestPosition = group(g).gbest;
        end
        
        
        %%     ״̬�ж�
        
        group(g).S(G) = MeanD(group(g).pop,group(g).GP,D);
        group(g).w1 = 1/(1+1.5*exp(-2.6*group(g).S(G)));
        if  group(g).S(G)<0.2
            group(g).Status = 'S3';
        end
        if 0.2<= group(g).S(G)&& group(g).S(G)<0.23
            if strcmp(group(g).Status,'S1')||strcmp(group(g).Status,'S2')
                group(g).Status = 'S2';
            else
                group(g).Status = 'S3';
            end
        end
        if 0.23<= group(g).S(G)&& group(g).S(G)<0.3
            if strcmp(group(g).Status,'S2')||strcmp(group(g).Status,'S3')
                group(g).Status = 'S3';
            else
                group(g).Status = 'S2';
            end
        end
        
        if 0.3<= group(g).S(G)&& group(g).S(G)<0.4
            group(g).Status = 'S2';
        end
        if 0.4<= group(g).S(G)&& group(g).S(G)<0.5
            if strcmp(group(g).Status,'S1')||strcmp(group(g).Status,'S4')
                group(g).Status = 'S1';
            else
                group(g).Status = 'S2';
            end
        end
        if 0.5<= group(g).S(G)&& group(g).S(G)<0.6
            if strcmp(group(g).Status,'S2')||strcmp(group(g).Status,'S1')
                group(g).Status = 'S2';
            else
                group(g).Status = 'S1';
            end
        end
        
        if 0.6<= group(g).S(G)&& group(g).S(G)<0.7
            group(g).Status = 'S1';
        end
        if 0.7<= group(g).S(G)&& group(g).S(G)<0.77
            if strcmp(group(g).Status,'S3')||strcmp(group(g).Status,'S4')
                group(g).Status = 'S4';
            else
                group(g).Status = 'S1';
            end
        end
        if 0.77<= group(g).S(G)&& group(g).S(G)<0.8
            if strcmp(group(g).Status,'S4')||strcmp(group(g).Status,'S1')
                group(g).Status = 'S1';
            else
                group(g).Status = 'S4';
            end
        end
        if  group(g).S(G)>=0.8
            group(g).Status ='S4';
        end
        %%    ����״̬��������
        
        if strcmp(group(g).Status,'S1')
            group(g).c1 = group(g).c1+(0.05+rand*0.05);
            group(g).c2 = group(g).c2-(0.05+rand*0.05);
        end
        
        
        if strcmp(group(g).Status,'S2')
            group(g).c1 = group(g).c1+(0.025+rand*0.025);
            group(g).c2 = group(g).c2-(0.025+rand*0.025);
        end
        
        
        if strcmp(group(g).Status,'S3')
            group(g).c1 = group(g).c1+(0.025+rand*0.025);
            group(g).c2 = group(g).c2+(0.025+rand*0.025);
        end
        
        
        if strcmp(group(g).Status,'S4')
            group(g).c1 = group(g).c1-(0.05+rand*0.05);
            group(g).c2 = group(g).c2+(0.05+rand*0.05);
        end
        if group(g).c1+group(g).c2 < 3
            group(g).c1 = group(g).c1*3/(group(g).c1+group(g).c2);
            group(g).c2 = 3-group(g).c1;
        end
        if group(g).c1+group(g).c2 > 4
            group(g).c1 = group(g).c1*4/(group(g).c1+group(g).c2);
            group(g).c2 = 4-group(g).c1;
        end
        group(g).c1 =  max(1.5,min(2.5,group(g).c1));
        group(g).c2 =  max(1.5,min(2.5,group(g).c2));
    end
    %     Tbest(G) = TotalBest;
    T(G) = TotalBest;
end
% figure(varargin{:});
% plot(T(1:50:1000),'b-','LineWidth',1,'Marker','x','MarkerFaceColor','b');
% % hold on;
% legend('PSO','PPSO','CCPSO','APSO','NPP');

end


